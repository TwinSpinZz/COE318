/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coe318.lab4;

/**
 *
 * @author Simrat Gill - 501100893
 */
public class Account {
    public String name;
    public int num;
    public double initialBal;
    public double bal;
    
    public Account (String name, int num, double initialBal){
        this.name = name;
        this.num = num;
        this.bal = initialBal;   
    }
    /**
     * @return the name
     */
    public String getName(){
        return name;
    }
    /**
     * @return the balance
     */
    public double getBalance(){
        return bal;   
    }
    /**
     * @return the account number
     */
    public int getNumber(){
        return num;
    }
    /**
     * Adds the amount into the balance if
     * the balance isn't less than or equal to zero.
     * Otherwise, it is false.
     * @param amount
     * @return
     */
    public boolean deposit(double amount){
        if (amount <= 0)
            return false;
        else{  
            this.bal += amount;
            return true;
        }
    }
     /**
     * Subtracts the amount out of the balance if
     * the balance isn't less than or equal to zero,
     * or if the amount is greater than the balance.
     * Otherwise, it is false.
     * @param amount
     * @return
     */
    public boolean withdraw (double amount){
        if (amount <= 0 || amount > getBalance())
            return false;
        else{
            this.bal -= amount;
            return true;
        }
    }
    
    @Override
    public String toString(){
        return "(" + getName() + ", " + getNumber() + ", " + String.format("$%.2f", getBalance()) + ")";
    }   
}
