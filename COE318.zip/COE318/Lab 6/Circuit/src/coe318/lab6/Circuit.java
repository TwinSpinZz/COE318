package coe318.lab6;
import java.util.ArrayList;
/**
 *
 * @author Simrat Gill - 501100893
 */

public class Circuit {
    private static Circuit instance = null;
    private static ArrayList<Resistor> resArray = new ArrayList<Resistor>();
    
    public static Circuit getInstance(){
        if (instance == null){
            instance = new Circuit();
        }
        return instance;
    }
    
    private Circuit(){
    }
    
    public void add(Resistor r){
        resArray.add(r);
    }
    
    @Override
    public String toString() {
        String s = "";
        for (Resistor i : resArray)
            s += i + "\n";
        return s;
        
    }
    
    public static void main(String[] args){
        Circuit circuit = Circuit.getInstance();
        Node node1 = new Node();
        Node node2 = new Node();
        Node node3 = new Node();
        Resistor res1 = new Resistor(30, node1, node2);
        Resistor res2 = new Resistor(50, node2, node3);
        System.out.println("Circuit is made of:");
        System.out.println(circuit);
    }
}