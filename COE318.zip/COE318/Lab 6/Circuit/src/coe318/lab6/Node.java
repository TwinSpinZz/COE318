package coe318.lab6;
/**
 *
 * @author Simrat Gill - 501100893
 */
public class Node {
    // num is a variable that changes everytime a Node is constructed. 
    // Whenever Node is constructed, numID is saved into the Node's specificNum.
    public static int numID = -1;
    public final int specificID;
    
    public Node(){
        numID++;
        this.specificID = numID;
    }
    // Gets the specific id of the node.
    public int getNum(){
        return this.specificID;
    }   
 // Returns the specific id of the node.
    public int getMaxNums(){
        return numID;
    }
    
    
    @Override
     public String toString() {
         return "" + getNum();
     }

}
