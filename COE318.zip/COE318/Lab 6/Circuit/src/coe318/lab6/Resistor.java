package coe318.lab6;

/**
 *
 * @author Simrat Gill - 501100893
 */
public class Resistor {
    // numRes is a variable that changes everytime a Resistor is constructed. 
    // Whenever Resistor is constructed, numRes is saved into the Resistor's specificNumRes. 

    public static int numIDRes = 0;
    public final int specificIDRes;
    public double res;
    public Node [] arrayNodes = new Node[2];
    
    public Resistor (double resistance, Node node1, Node node2){
        // if the resistance is lower than 1, it throws an error, otherwise, 
        // a specific ID is assigned and the res and elements of arrayNodes are initialized.
        if (resistance < 1)
            throw new IllegalArgumentException("Resistance must be above 0.");
        else{
        numIDRes++;
        this.specificIDRes = numIDRes;
            res = resistance;
            arrayNodes[0] = node1;
            arrayNodes[1] = node2;
            
        }
        Circuit circuit = Circuit.getInstance();
        circuit.add(this);
    }
    // Returns the array of nodes.
    public Node [] getNodes(){
        return arrayNodes;
    }
    
    @Override
    public String toString(){
        return "R" + specificIDRes + " " + arrayNodes[0] + " " + arrayNodes[1] + " " + res;
    }
}
