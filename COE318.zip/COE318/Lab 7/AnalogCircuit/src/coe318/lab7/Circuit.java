package coe318.lab7;
import java.util.*;
/**
 *
 * @author Simrat Gill - 501100893
 */

public class Circuit {
    private static Circuit instance = null;
    private static ArrayList<Resistor> resArray = new ArrayList<Resistor>();
    
    public static Circuit getInstance(){
        if (instance == null){
            instance = new Circuit();
        }
        return instance;
    }
    
    private Circuit(){
    }
    
    public void add(Resistor r){
        resArray.add(r);
    }
    
    @Override
    public String toString() {
        String s = "";
        for (Resistor i : resArray)
            s += i + "\n";
        return s;
        
    }
}