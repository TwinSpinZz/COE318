package coe318.lab7;
/**
 *
 * @author Simrat Gill - 501100893
 */
public class Node {
    // num is a variable that changes everytime a Node is constructed. 
    // Whenever Node is constructed, numID is saved into the Node's specificNum.
    public int numID;
    public static int specificID=0;
    
    public Node(){
        this.numID = specificID;
        specificID++;
    }
    // Gets the specific id of the node.
    public int getNum(){
        return this.specificID;
    }  
 // Returns the specific id of the node.
    public int getMaxNums(){
        return numID;
    }
    
    
    @Override
     public String toString() {
         return "" + this.numID;
     }

}
