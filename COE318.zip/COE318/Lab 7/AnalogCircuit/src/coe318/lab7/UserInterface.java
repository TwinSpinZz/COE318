/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coe318.lab7;

/**
 *
 * @author Simrat Gill - 501100893
 */
public interface UserInterface {
    public void start();
         
    public void run();
    
    public void display();
    
    public void spice();
    
    public void end();
    
}
