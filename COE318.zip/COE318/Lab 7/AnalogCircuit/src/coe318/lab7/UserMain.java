/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coe318.lab7;
import java.util.*;
/**
 *
 * @author Simrat Gill - 501100893
 */
public class UserMain implements UserInterface{
    String input = "";
    ArrayList<Object> element = new ArrayList<>();
    Scanner uin = new Scanner(System.in);
    
    public void start(){
        display();
        run();
    }
    
    public void run(){
        while(true){
            input = uin.nextLine().trim();
            
            if(input.equalsIgnoreCase("end")){
                end();
                break;
            }
            
            else if(input.equalsIgnoreCase("spice")){
                spice();
            }
            
            else{
                String[] value = input.split(" ");
                
                if(value.length != 4){
                    System.out.println("\nThere seems to be an issue with your input. \nPlease try again");
                }
                else{
                    if(input.toLowerCase().startsWith("v")){
                        double temp;
                        
                        Node n1 = new Node();
                        Node n2 = new Node();
                        
                        n1.numID = Integer.parseInt(value[1]);
                        n2.numID = Integer.parseInt(value[2]);
                        
                        temp = Double.parseDouble(value[3]);
                        Voltage v = new Voltage(temp, n1, n2);
                        
                        element.add(v);
                    }
                    else if (input.toLowerCase().startsWith("r")){
                       double temp;
                       
                       Node n1 = new Node();
                       Node n2 = new Node();
                       
                       n1.numID = Integer.parseInt(value[1]);
                       n2.numID = Integer.parseInt(value[2]);
                       
                       temp = Double.parseDouble(value[3]);
                       Resistor r = new Resistor(temp, n1, n2);
                       
                       element.add(r);                              
                    }
                }
            }  
        }
    }
    
    public void display(){
        System.out.println("Enter your input:");
    }
    
   public void spice(){
        for(Object o : element)
            System.out.println(o);
    }
   
   public void end(){
       System.out.println("All done");
   }
   
   public static void main(String[] args){
       UserMain m = new UserMain();
       m.start();
   }
}