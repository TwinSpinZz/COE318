/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package coe318.lab7;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Simrat Gill - 501100893
 */
public class VoltageTest {
    
    //Instance variables needed for the VoltageTest class
    Node node1 = new Node();
    Node node2 = new Node();
    Voltage voltage1 = new Voltage (25, node1, node2);
    
    public VoltageTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getNodes method, of class Voltage.
     */

    /**
     * Test of toString method, of class Voltage.
     */
    @Test
    public void testToString() {
        
        Voltage instance = voltage1;
        String result = instance.toString();
        assertTrue(result.contains("V1 0 1 DC 25.0"));
        System.out.println("Voltage Test Passed");

    }
    @Test
    public void testNode() {
        
        Node n1 = new Node();
        Node n2 = new Node();
        Node[] nodes = {n1,n2};
        Voltage v1 = new Voltage(25,n1,n2);
        Node[] n = v1.getNode();
        assertArrayEquals(n, nodes);
        System.out.println("Node Test Passed");

    }
}